(function () {
  function hydrateSlide(slide) {
    if (!slide) return;
    slide.querySelectorAll('source[data-srcset]').forEach((source) => {
      source.setAttribute('srcset', source.dataset.srcset);
      delete source.dataset.srcset;
    });
    slide.querySelectorAll('img[data-src]').forEach((img) => {
      if (img.dataset.srcset) {
        img.setAttribute('srcset', img.dataset.srcset);
        delete img.dataset.srcset;
      }
      if (img.dataset.sizes) {
        img.setAttribute('sizes', img.dataset.sizes);
        delete img.dataset.sizes;
      }
      img.setAttribute('src', img.dataset.src);
      delete img.dataset.src;
    });
  }

  function initSlider(root) {
    if (!root || root.dataset.sliderInit === '1') return;
    root.dataset.sliderInit = '1';

    const track = root.querySelector('[data-post-card-track]');
    const slides = Array.from(root.querySelectorAll('[data-post-card-slide]'));
    const dots = Array.from(root.querySelectorAll('[data-post-card-dot]'));
    if (!track || slides.length < 2) return;

    let index = 0;
    let touchStartX = 0;
    let touchStartY = 0;
    let moved = false;

    function update() {
      track.style.transform = `translate3d(-${index * 100}%, 0, 0)`;
      dots.forEach((dot, i) => {
        const active = i === index;
        dot.classList.toggle('is-active', active);
        dot.setAttribute('aria-current', active ? 'true' : 'false');
      });
      hydrateSlide(slides[index]);
      hydrateSlide(slides[index + 1]);
      hydrateSlide(slides[index - 1]);
    }

    function goTo(nextIndex) {
      index = Math.max(0, Math.min(slides.length - 1, nextIndex));
      update();
    }

    dots.forEach((dot, i) => {
      dot.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        goTo(i);
      });
    });

    root.addEventListener(
      'touchstart',
      (event) => {
        if (event.touches.length !== 1) return;
        touchStartX = event.touches[0].clientX;
        touchStartY = event.touches[0].clientY;
        moved = false;
      },
      { passive: true }
    );

    root.addEventListener(
      'touchmove',
      (event) => {
        if (event.touches.length !== 1) return;
        const dx = event.touches[0].clientX - touchStartX;
        const dy = event.touches[0].clientY - touchStartY;
        if (Math.abs(dx) > 10 && Math.abs(dx) > Math.abs(dy)) moved = true;
      },
      { passive: true }
    );

    root.addEventListener(
      'touchend',
      (event) => {
        if (event.changedTouches.length !== 1) return;
        const dx = event.changedTouches[0].clientX - touchStartX;
        const dy = event.changedTouches[0].clientY - touchStartY;
        if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy)) return;
        goTo(index + (dx < 0 ? 1 : -1));
      },
      { passive: true }
    );

    slides.forEach((slide) => {
      slide.addEventListener('click', (event) => {
        if (!moved) return;
        event.preventDefault();
        event.stopPropagation();
        moved = false;
      });
    });

    update();
  }

  function initAll() {
    document.querySelectorAll('[data-post-card-slider]').forEach((root) => initSlider(root));
  }

  document.addEventListener('DOMContentLoaded', initAll);
  document.body.addEventListener('htmx:afterSettle', initAll);
})();
